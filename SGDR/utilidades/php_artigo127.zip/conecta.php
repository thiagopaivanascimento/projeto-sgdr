<?
/*
----------------------------------------------------------------------
Arquivo .............: AJAX + PHP                                     
Desenvolvido por ....: J�lio C�sar Martini                            
Mat�ria .............: Artigo 127 - www.imasters.com.br               
Criado em  ..........: 14/03/2006                                     
----------------------------------------------------------------------
*/

//CONECTA AO MYSQL                                       
$conn = mysql_connect("127.0.0.1", "root", "linux4u")    
          or die("Erro na conex�o com a base de dados"); 

//SELECIONA A BASE DE DADOS                
$db = mysql_select_db("imasters", $conn)   
         or die("Erro na sele��o da base de dados");  
?>