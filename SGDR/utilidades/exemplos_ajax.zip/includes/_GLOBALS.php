<? 
global $EnderecoSite;
$EnderecoSite = "http://www.japs.etc.br/ajax/";
?>